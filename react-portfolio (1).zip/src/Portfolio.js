import React from 'react';

export default function Portfolio() {
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold">Annapoorna K N</h1>
        <p className="text-lg text-gray-600">Full Stack Web Developer | MCA Student</p>
      </header>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-blue-600">About Me</h2>
        <p className="mt-2 text-gray-700">
          Motivated and quick-learning postgraduate student with hands-on experience in full stack development. 
          Passionate about building user-friendly applications and solving real-world problems through code.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-blue-600">Projects</h2>
        <ul className="list-disc list-inside text-gray-700">
          <li>💊 Home Remedies Website – Interactive UI with login & remedy display (React + Node.js + MongoDB)</li>
          <li>📚 Recipe Book App – Categorized recipes with authentication (React + Express + MongoDB)</li>
          <li>📝 Student Feedback Form – Collects and stores feedback securely with login (MERN Stack)</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-blue-600">Skills</h2>
        <p className="text-gray-700">
          HTML, CSS, JavaScript, React, Node.js, Express, MongoDB, Java, C Programming
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-blue-600">Resume</h2>
        <a href="Annapoorna_KN_Resume_With_LinkedIn.pdf" download className="text-blue-500 underline">
          Download Resume
        </a>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-blue-600">Contact</h2>
        <p className="text-gray-700">
          Email: annapoornaa429@gmail.com<br/>
          LinkedIn: <a href="https://www.linkedin.com/in/annapoorna-k-n-522508331" className="text-blue-500 underline">annapoorna-k-n</a>
        </p>
      </section>
    </div>
  );
}
